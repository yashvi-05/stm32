#include <analogWrite.h>
#include "motor.h"

#define constrain(val, Omin, Omax) ((val > Omax) ? Omax : (val < Omin) ? Omin : val)

MOTOR::MOTOR(int dir1, int pwm2, int max_speed) {
  this->dir1 = dir1;
  this->pwm2 = pwm2;
  this->max_speed = max_speed;
  pinMode(dir1, OUTPUT);
  pinMode(pwm2, OUTPUT);
}

void MOTOR::clockwise(int p) {
  p = constrain(p, 0, 230);
  digitalWrite(dir1, LOW);
  analogWrite(pwm2, p);
}

void MOTOR::anticlockwise(int p) {
  p = constrain(p, 0, 230);
  digitalWrite(dir1, HIGH);
  analogWrite(pwm2, p);
}

void MOTOR::breakmotor() {
  digitalWrite(dir1, LOW);
  analogWrite(pwm2, 0);
}

void MOTOR::set_velocity(float speed) {
  speed = constrain(speed, -this->max_speed, this->max_speed);
  if (speed > 0) direction = true;
  else direction = false;
  uint8_t pwm = (uint8_t)map(fabs(speed), 0, max_speed, 0, 255);
  if (speed == 0) {
    this->breakmotor();
    return;
  }
  if (direction == true) {
    this->anticlockwise(pwm);
  } else {
    this->clockwise(pwm);
  }
}
