#include "pid-controller.h"

/**
* Allocates a PIDController with the given constants for kp, ki, and kd.
*
* @param kp The proportional coefficient.
* @param ki The integral coefficient.
* @param kd The derivative coefficient.
* @param period The period between controller updates in seconds.
* @throws IllegalArgumentException if kp < 0
* @throws IllegalArgumentException if ki < 0
* @throws IllegalArgumentException if kd < 0   
* @throws IllegalArgumentException if period <= 0
*/
Algorithm::PID::PID(double kp, double ki, double kd, double period) {
  this->kp = kp;
  this->ki = ki;
  this->kd = kd;
  this->period = period / 1000.0;
}

/**
* Returns the next output of the PID controller.
*
* @param value The current input of the process variable.
* @param low The minimum value of the process variable.
* @param high The new setpoint of the process variable.
* @return The constrain value output.
*/
double Algorithm::PID::clamp(double value, double low, double high) {
  return value < low ? low : (value > high ? high : value);
}

/**
* Returns the next output of the PID controller.
*
* @param input The current input of the process variable.
* @param setpoint The new setpoint of the controller.
* @return The next controller output.
*/
double Algorithm::PID::calculate(double input, double setpoint) {
  this->setpoint = setpoint;
  return this->calculate(input);
}

/**
* Returns the next output of the PID controller.
*
* @param input The current input of the process variable.
* @return The next controller output.
*/
double Algorithm::PID::calculate(double input) {
  this->input = input;
  this->prev_error = this->position_error;
  this->position_error = this->setpoint - this->input;
  this->velocity_error = (this->position_error - this->prev_error) / this->period;
  if (this->ki) {
    this->total_error = this->clamp(
      this->total_error + this->position_error * this->period,
      this->min_intergral / this->ki,
      this->max_intergral / this->ki);
  }
  this->output = this->kp * this->position_error + this->ki * this->total_error + this->kd * this->velocity_error;
  this->output = this->clamp(this->output, this->min_limit, this->max_limit);
  return this->output;
}

/**
* Sets the PID Controller gain parameters.
*
* Set the proportional, integral, and differential coefficients.
*
* @param kp The proportional coefficient.
* @param ki The integral coefficient.
* @param kd The derivative coefficient.
*/
void Algorithm::PID::set_tunings(double kp, double ki, double kd) {
  this->kp = kp;
  this->ki = ki;
  this->kd = kd;
}

/**
* Sets the Proportional coefficient of the PID controller gain.
*
* @param kp The proportional coefficient. Must be >= 0.
*/
void Algorithm::PID::set_kp(double kp) {
  this->kp = kp;
}

/**
* Sets the Integral coefficient of the PID controller gain.
*
* @param ki The integral coefficient. Must be >= 0.
*/
void Algorithm::PID::set_ki(double ki) {
  this->ki = ki;
}

/**
* Sets the Differential coefficient of the PID controller gain.
*
* @param kd The differential coefficient. Must be &gt;= 0.
*/
void Algorithm::PID::set_kd(double kd) {
  this->kd = kd;
}

/**
* Sets the periodic time for calculation of PID controller output.
*
* @param kd The differential coefficient. Must be &gt;= 0.
*/
void Algorithm::PID::set_period(double period) {
  this->period = period / 1000.0;
}


/**
* Sets the setpoint for the PIDController.
*
* @param setpoint The desired setpoint.
*/
void Algorithm::PID::set_setpoint(double setpoint) {
  this->setpoint = setpoint;
  this->position_error = this->setpoint - this->input;
  this->velocity_error = (this->position_error - this->input) / this->period;
}

/**
* Sets the minimum and maximum values for the integrator.
*
* When the cap is reached, the integrator value is added to the controller output rather than
* the integrator value times the integral gain.
*
* @param min_intergral The minimum value of the integrator.
* @param max_intergral The maximum value of the integrator.
*/
void Algorithm::PID::set_intergrator_range(double min_intergral, double max_intergral) {
  this->min_intergral = min_intergral;
  this->max_intergral = max_intergral;
}

/**
* Sets the error which is considered tolerable for use with atSetpoint().
*
* @param position_tolerance Position error which is tolerable.
*/
void Algorithm::PID::set_tolerance(double position_tolerance) {
  this->set_tolerance(position_tolerance, __INT64_MAX__);
}

/**
* Sets the error which is considered tolerable for use with atSetpoint().
*
* @param position_tolerance Position error which is tolerable.
* @param velocity_tolerance Velocity error which is tolerable.
*/
void Algorithm::PID::set_tolerance(double position_tolerance, double velocity_tolerance) {
  this->position_tolerance = position_tolerance;
  this->velocity_tolerance = velocity_tolerance;
}

/**
* Sets the minimum and maximum values for the Output .
*
* Rather then using the max and min ouput range as constraints, it considers them to be the
* same point and automatically calculates the in-range value for the Output
*
* @param min_limit The minimum value expected from the Output.
* @param max_limit The maximum value expected from the Output.
*/
void Algorithm::PID::set_output_limits(double min_limit, double max_limit) {
  this->min_limit = min_limit;
  this->max_limit = max_limit;
}

/**
* Returns true if the error is within the tolerance of the setpoint.
*
* This will return false until at least one input value has been computed.
*
* @return Whether the error is within the acceptable bounds.
*/
bool Algorithm::PID::at_setpoint() {
  return abs(this->position_error) < this->position_tolerance && abs(this->velocity_error) < this->velocity_tolerance;
}

/**
* Get the Proportional coefficient.
*
* @return proportional coefficient
*/
double Algorithm::PID::get_kp() {
  return this->kp;
}

/**
* Get the Integral coefficient.
*
* @return integral coefficient
*/
double Algorithm::PID::get_ki() {
  return this->ki;
}

/**
* Get the Differential coefficient.
*
* @return differential coefficient
*/
double Algorithm::PID::get_kd() {
  return this->kd;
}

/**
* Returns the period of this controller.
*
* @return the period of the controller.
*/
double Algorithm::PID::get_period() {
  return this->period;
}

/**
* Returns the current setpoint of the PIDController.
*
* @return The current setpoint.
*/
double Algorithm::PID::get_setpoint() {
  return this->setpoint;
}

/**
* Returns the current output of the PIDController.
*
* @return The current output.
*/
double Algorithm::PID::get_output() {
  return this->output;
}

/**
* Returns the difference between the setpoint and the input.
*
* @return The error.
*/
double Algorithm::PID::get_position_error() {
  return this->position_error;
}

/**
* Returns the velocity error.
*
* @return The velocity error.
*/
double Algorithm::PID::get_velocity_error() {
  return this->velocity_error;
}

/** Resets the previous error and the integral term. */
void Algorithm::PID::reset() {
  this->position_error = this->velocity_error = this->total_error = this->prev_error = 0;
}
