#ifndef IMU_H
#define IMU_H

#define MILLI_G_TO_MS2 0.0098067 ///< Scalar to convert milli-gs to m/s^2
#define DEGREE_SCALE 0.01        ///< To convert the degree values

#include "Arduino.h"

namespace Sensors {
  class IMU {
    private:
      HardwareSerial *IMU_SERIAL;
      float yaw,     ///< Yaw in Degrees
        pitch,     ///< Pitch in Degrees
        roll;      ///< Roll in Degrees
    public:
      IMU(HardwareSerial *IMU_SERIAL);
      bool update();
      float getYaw() { return -yaw; }
  };
};

#endif
