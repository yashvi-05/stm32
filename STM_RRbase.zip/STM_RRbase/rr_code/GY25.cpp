#include "GY25.h"

GY_25::GY_25(HardwareSerial *Serial) {
  GYSerial = Serial;
}
void GY_25::GY25_Transmit() {
  GYSerial->write(mode);
  GYSerial->write(command);
}

void GY_25::GY25_Receive() {
  if (GYSerial->available() < 7) return;
  if (GYSerial->read() != 0xAA) return;

  for (int i = 1; i < 8; i++) {
    this->Re_buf[i] = GYSerial->read();
  }
  if ( this->Re_buf[7] != 0x55) return;
  this->z = (int16_t)(Re_buf[1] << 8 | Re_buf[2]) / 100.0;
  
}  
