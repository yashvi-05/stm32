#include <stdint.h>
#include <math.h>
#include <Arduino.h>

namespace Controller {
class Ps3Controller {
protected:
  struct __direction {
    uint8_t up,
      down,
      left,
      right,
      clockwise,
      anti_clockwise,
      lock;
    float angle ;
    uint32_t commands = 0;
    uint8_t checksum = 0;
  };
  HardwareSerial *serialport;
public:
  struct __direction dir;
  Ps3Controller(HardwareSerial *serialport);
  bool send();
  bool add_command(uint8_t pos);
  void reset();
};

};