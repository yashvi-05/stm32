#include "ps3-controller.h"
uint8_t *stream, idx = 0;
Controller::Ps3Controller::Ps3Controller(HardwareSerial *serialport) {
  this->serialport = serialport;
}

bool Controller::Ps3Controller::add_command(uint8_t pos) {
  if (pos > 32) {
    return -1;
  }
  dir.commands = dir.commands | (int)pow(2, pos);
  return 0;
}

void Controller::Ps3Controller::reset() {
  dir.commands = 0;
}

bool Controller::Ps3Controller::send() {
  // do send routine
  free(stream);
  dir.checksum = 0;
  stream = (uint8_t *)calloc(1, sizeof(dir) + 1);

  memcpy(stream, &dir, sizeof(dir));

  for (idx = 0; idx < sizeof(dir); idx++)
    dir.checksum = (uint8_t)((dir.checksum + stream[idx]));

  stream[sizeof(dir)] = dir.checksum;

  for (idx = 0; idx < sizeof(dir) + 1; idx++)
    serialport->write(stream[idx]);

  Controller::Ps3Controller::reset();
  return 0;
}