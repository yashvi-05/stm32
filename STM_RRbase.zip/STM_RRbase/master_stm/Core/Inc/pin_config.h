/*
 *  pin_config.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#ifndef PIN_CONFIG_H_
#define PIN_CONFIG_H_

#include "main.h"

#define ps3_uart &huart1
#define imu_uart &huart4
#define base_uart &huart3

enum COMMANDS {
	AUTO_BASE_LEFT,
	AUTO_BASE_RIGHT,
	SET_POSE
};
COMMANDS commands;

#endif /* PIN_CONFIG_H_ */
