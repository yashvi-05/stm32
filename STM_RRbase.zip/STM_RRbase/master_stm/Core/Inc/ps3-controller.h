/*
 *  ps3-controller.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */


#ifndef PS3CONTROLLER_H
#define PS3CONTROLLER_H

#include "stm32f4xx.h"
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cstdlib>

enum Controller_Status {
  CONTROLLER_PASS,
  CONTROLLER_TRANSMIT_ERROR,
  CONTROLLER_RECEIVE_ERROR,
  CONTROLLER_CHECKSUM_ERROR
};

namespace Controller {
class Ps3Controller {
  struct __direction {
    uint8_t up,
      down,
      left,
      right,
      clockwise,
      anti_clockwise;
    float angle;
    //circle,cross,square,triangle,l2,r2;
    //			int dir_pick_motor = 0, dir_pick_end_motor = 0, dir_passing_motor= 0;
    //            int ball_distance = 0, ball_angle = 0;
    uint32_t commands = 0;
    uint8_t checksum = 0;
  };
  UART_HandleTypeDef *huart;
  uint8_t *stream,
    request = 128,
    wait_time = 30,
    idx = 0,
    buffer_size = sizeof(struct __direction);
  HAL_StatusTypeDef status;

public:
  struct __direction direction;
  Ps3Controller(UART_HandleTypeDef *huart);
  Controller_Status ps_request();
  Controller_Status update();
};
};

#endif  // PS3CONTROLLER_H
