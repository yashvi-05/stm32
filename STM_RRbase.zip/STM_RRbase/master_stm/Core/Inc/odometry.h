/*
 *  odometry.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 *  refer : https://youtu.be/Av9ZMjS--gY?si=whd1_PQFPXv-y8-g
 */

#ifndef ODOMETERY_H
#define ODOMETERY_H

#include <cmath>
#include "pid-controller.h"

enum ODOM_Status {
  ODOM_PASS,
  ODOM_FAIL
};

typedef struct __Pose2D {
  double x, y, z;
} Pose2D;

typedef struct __Velocity2D {
  float Vx, Vy, Vz;
} Velocity2D;

namespace Localization {
class Odometry {
protected:
  Pose2D pose;
  Velocity2D speed;
  long long *encoderX, *encoderY;
  float *angle;
  float radius = 0.029, factorX = 0, factorY = 0;  // radius is always in meters
  long long currX = 0, currY = 0, prevX = 0, prevY = 0;
  double diffX = 0, diffY = 0, diffZ = 0, prevZ = 0;
  float x_offset = 0.08, y_offset = 0.12;
  float xLocal, yLocal;
public:
  Odometry(long long *encoderX, long long *encoderY, float *angle, float radius);
  void set_offsets(float x_offset, float y_offset);
  //		void update_position();
  float get_diffZ() {
    return diffZ;
  };
  Pose2D get_position();
  ODOM_Status set_position(Pose2D pose);
  Velocity2D get_speed(float dT);
  Pose2D get_reletive_position(float distance, float angle);
};
};

#endif
