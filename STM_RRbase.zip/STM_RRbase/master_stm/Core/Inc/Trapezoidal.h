/*
 *  Trapezoidal.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 *  refer : https://www.youtube.com/watch?v=yi45PgCqucs
 */

#ifndef TRAPEZOIDAL_H_
#define TRAPEZOIDAL_H_

#include "main.h"

namespace Profile {
class Trapezoidal {
protected:
  float t = 0, tb = 0, update_time = 0.005;
  float distance = 0;
  float v_max = 0;
  float factor = 1.5;
public:
  Trapezoidal(float update_time = 0.005, float factor = 1.5);
  float calculate_distance(float q0, float qf, float tf, float v = 10);
  void reset() {
    this->t = 0;
  };
  bool is_complete(float tf) {
    return this->t < tf ? false : true;
  };
};
}



#endif /* SEVEN_SEGMENT_H_ */
