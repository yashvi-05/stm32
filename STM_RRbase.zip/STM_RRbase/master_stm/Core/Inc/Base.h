/*
 * base.h
 *
 *  Created on: Apr 25, 2024
 *      Author: khush
 */


#ifndef INC_BASE_H_
#define INC_BASE_H_

#include "cytron.h"

class Base {
private:
  static Actuators::Motor* m1;
  static Actuators::Motor* m2;
  static Actuators::Motor* m3;
public:
  Base(Actuators::Motor* Motor1, Actuators::Motor* Motor2, Actuators::Motor* Motor3);
  void base_init();
  void Forward(int p2, int p3);
  void Backward(int p2, int p3);
  void baseRight(int p1, int p2, int p3);
  void baseLeft(int p1, int p2, int p3);
  void baseClockWise(int p1, int p2, int p3);
  void baseAnticlockWise(int p1, int p2, int p3);
  void baseBreak();
};

#endif /* INC_BASE_H_ */
