/*
 * pid-controller.h
 *
 *  Created on: Sep 4, 2022
 *      Author: Author: shahjesa15, pheonix17, shubh_gajjar07
 */

#ifndef INC_PID_CONTROLLER_H_
#define INC_PID_CONTROLLER_H_
#include "main.h"
#include "math.h"

namespace Algorithm {
class PID {
protected:
  double kp, ki, kd,
    position_error = 0, velocity_error = 0,
    max_intergral = 1.0, min_intergral = -1.0,
    period = 5, total_error = 0, prev_error = 0,
    position_tolerance = 0.05, velocity_tolerance = __INT64_MAX__,
    min_limit = -255.0, max_limit = 255.0,
    setpoint, input = 0, output = 0;
  double clamp(double value, double low, double high);
public:
  PID(double kp, double ki, double kd, double period);
  double calculate(double input);
  double calculate(double input, double setpoint);
  void set_tunings(double kp, double ki, double kd);
  void set_kp(double kp);
  void set_ki(double ki);
  void set_kd(double kd);
  void set_period(double period);
  void set_setpoint(double setpoint);
  void set_intergrator_range(double min_intergral, double max_intergral);
  void set_tolerance(double position_tolerance);
  void set_tolerance(double position_tolerance, double velocity_tolerance);
  void set_output_limits(double min_limit, double max_limit);
  bool at_setpoint();
  double get_kp();
  double get_ki();
  double get_kd();
  double get_period();
  double get_output();
  double get_setpoint();
  double get_position_error();
  double get_velocity_error();
  void reset();
};
};
#endif /* INC_PID_CONTROLLER_H_ */
