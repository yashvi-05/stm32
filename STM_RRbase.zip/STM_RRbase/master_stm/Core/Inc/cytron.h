/*
 *  cytron.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#ifndef MOTOR_H
#define MOTOR_H

#include "main.h"
#include <cmath>

#define constrain(value, min, max) (value > max) ? max : (value < min) ? min : value
#define map(value, from_low, from_high, to_low, to_high) ((value - from_low) * (to_high - to_low) / (from_high - from_low) + (to_low))

#define ML 0                         // left channel for cytron 0b0000'0'000
#define MR 1                         // right channel for cytron 0b0000'1'000

namespace Actuators {
    class Motor {
    	private:
          	void send_packet();                     // send data to cytron-mdds30a
        protected:
    		UART_HandleTypeDef* huart;
    	    uint8_t cytron_packet[4] = {85, 0, 0, 0};  // packet for cytron-mdds30a
            float max_speed = 0;
            bool direction = false;
            uint8_t pwm = 0;
        public:
            Motor(UART_HandleTypeDef* huart, uint8_t address, uint8_t channel, uint32_t rpm);
            void init();
            void anti_clockwise(uint8_t speed);
			void clockwise(uint8_t speed);
			void brake();
			void set_velocity(float speed);
			uint8_t get_pwm() { return this->pwm; };
			void set_max_speed(float rpm) { this->max_speed = rpm * 0.10471; };
    };
};

#endif
