/*
 *  Tribase.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#ifndef TRIBASE_H
#define TRIBASE_H

#include "main.h"
#include "odometry.h"
#include "pid-controller.h"
#include "CYTRON.h"



#define map(value, from_low, from_high, to_low, to_high) ((value - from_low) * (to_high - to_low) / (from_high - from_low) + (to_low))

namespace DriveTrain {
class Tribase {
private:
  static Actuators::Motor* motorA;
  static Actuators::Motor* motorB;
  static Actuators::Motor* motorC;
protected:
  Velocity2D feedback;
  Pose2D* pose;
  float max_velocity;
  float speedA, speedB, speedC, center = 0.4, radius;
  float Vx = 0, Vy = 0, Vw = 0, yaw = 0;
  float errorX, errorY, errorZ;
  float Kp = 1, Ki = 0, Kd = 0.025;
  uint8_t data[16], idx = 0;
  uint16_t temp = 0;
  float currReadings, input, prevReadings,outputA,outputB, output,prevtime;
  int32_t encoderA ;
public:
  Algorithm::PID *controlX, *controlY, *controlZ, *controlPoseX, *controlPoseY, *controlPoseZ, *controllerA, *controllerB, *controllerC;
  Tribase(Actuators::Motor* motorA, Actuators::Motor* motorB, Actuators::Motor* motorC, Pose2D* pose, float center, float radius);
  void set_feedback(Velocity2D feedback) {
    this->feedback = feedback;
  };
  void set_max_velocity(float max_velocity) {
    this->max_velocity = max_velocity;
  };
  void set_speed(float Vx, float Vy, float VW, int32_t encA, int32_t encB, int32_t enc);
  void set_speed(float Vx, float Vy, int32_t encA, int32_t encB, int32_t encC);
  void set_yaw(float yaw) {
    this->yaw = yaw;
  };
  float get_errorX() {
    return errorX;
  };
  float get_errorY() {
    return errorY;
  };
  float get_errroZ() {
    return errorZ;
  };
  float get_max_velocity() {
    return max_velocity;
  }
  float get_yaw() {
    return yaw;
  };
  Velocity2D set_position(Pose2D* pose, float poseX, float poseY, float poseZ);
  void send_packet(float Asetpoint, int32_t encA, float Bsetpoint, int32_t encB, float Csetpoint, int32_t encC);
};
};

#endif
