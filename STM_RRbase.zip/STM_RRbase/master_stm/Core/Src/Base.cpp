#include "base.h"

// Define the static pointers for CYTRON motors
Actuators::Motor* Base::m1;
Actuators::Motor* Base::m2;
Actuators::Motor* Base::m3;

Base::Base(Actuators::Motor* Motor1, Actuators::Motor* Motor2, Actuators::Motor* Motor3) {
  m1 = Motor1;
  m2 = Motor2;
  m3 = Motor3;
}

void Base::base_init() {
  m1->init();
  m2->init();
  m3->init();
}

void Base::Backward(int p2, int p3) {
  m1->brake();
  m2->clockwise(p2);
  m3->anti_clockwise(p3);
}

void Base::Forward(int p2, int p3) {
  m1->brake();
  m2->anti_clockwise(p2);
  m3->clockwise(p3);
}

void Base::baseLeft(int p1, int p2, int p3) {
  m1->anti_clockwise(p1);
  m2->clockwise(p2);
  m3->clockwise(p3);
}

void Base::baseRight(int p1, int p2, int p3) {
  m1->clockwise(p1);
  m2->anti_clockwise(p2);
  m3->anti_clockwise(p3);
}

void Base::baseAnticlockWise(int p1, int p2, int p3) {
  m1->anti_clockwise(p1);
  m2->anti_clockwise(p2);
  m3->anti_clockwise(p3);
}

void Base::baseClockWise(int p1, int p2, int p3) {
  m1->clockwise(p1);
  m2->clockwise(p2);
  m3->clockwise(p3);
}

void Base::baseBreak() {
  m1->brake();
  m2->brake();
  m3->brake();
}
