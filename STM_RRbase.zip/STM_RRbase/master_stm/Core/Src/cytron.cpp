/*
 *  cytron.cpp
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#include "cytron.h"
uint8_t  dummy_uint8_t = 128;

Actuators::Motor::Motor(UART_HandleTypeDef* huart, uint8_t address, uint8_t channel, uint32_t rpm){
	this->huart = huart;
	cytron_packet[1] = channel << 3 | address;
	this->max_speed = rpm * 0.10471;
}

void Actuators::Motor::init() {
	HAL_Delay(1000);
	HAL_UART_Transmit(huart, &dummy_uint8_t, sizeof(dummy_uint8_t), 10);
	HAL_Delay(500);
}

void Actuators::Motor::clockwise(uint8_t speed) {
	cytron_packet[2] = map(speed, 0, 255, 127, 255);  // mapping the command uint8_t for speed as per locked anti-phase
	send_packet();                                  // send packets to cytron-mdds30a
}

void Actuators::Motor::anti_clockwise(uint8_t speed) {
    cytron_packet[2] = map(speed, 0, 255, 127, 0); // mapping the command uint8_t for speed as per locked anti-phase
    send_packet();                                   // send packets to cytron-mdds30a
}

void Actuators::Motor::brake() {
    cytron_packet[2] = 127;                         // brake in locked anti-phase is given by 127
    send_packet();                                  // send packets to cytron-mdds30a
}

void Actuators::Motor::set_velocity(float speed) {
	speed = constrain(speed, -this->max_speed, this->max_speed);
	if (speed > 0) direction = true;
	else direction = false;
	uint8_t pwm = (uint8_t)map(fabs(speed), 0, this->max_speed, 0, 255);
	if (speed == 0) {
		this->brake();
		return;
	}
	if (direction == true) {
		this->anti_clockwise(pwm);
	} else {
		this->clockwise(pwm);
	}
}

void Actuators::Motor::send_packet() {
	cytron_packet[3] = cytron_packet[0] + cytron_packet[1] + cytron_packet[2];  // check sum calculation for cytron-mdds30a
	HAL_UART_Transmit(huart, cytron_packet, sizeof(cytron_packet), 10);
}
