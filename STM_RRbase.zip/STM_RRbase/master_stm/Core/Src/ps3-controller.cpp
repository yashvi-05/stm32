/*
 *  ps3-controller.cpp
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#include "ps3-controller.h"

Controller::Ps3Controller::Ps3Controller(UART_HandleTypeDef *huart) {
  this->huart = huart;
  stream = (uint8_t *)malloc(buffer_size + 1);
}

Controller_Status Controller::Ps3Controller::ps_request() {
  if (HAL_UART_Transmit_IT(huart, &request, 1) != HAL_OK)
    return CONTROLLER_TRANSMIT_ERROR;
  return CONTROLLER_PASS;
}

Controller_Status Controller::Ps3Controller::update() {
  bzero(stream, sizeof(struct __direction));
  if (HAL_UART_Receive(huart, stream, buffer_size + 1, wait_time) != HAL_OK)
    return CONTROLLER_RECEIVE_ERROR;
  direction.checksum = 0;
  for (idx = 0; idx < buffer_size; idx++)
    direction.checksum = (uint8_t)(direction.checksum + stream[idx]);
  if (direction.checksum != stream[buffer_size])
    return CONTROLLER_CHECKSUM_ERROR;
  memcpy(&direction, stream, buffer_size);
  return CONTROLLER_PASS;
}
