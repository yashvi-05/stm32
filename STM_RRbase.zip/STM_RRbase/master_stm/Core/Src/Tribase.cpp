/*
 *  Tribase.cpp
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#include "Tribase.h"
#include "CYTRON.h"


Actuators::Motor* DriveTrain::Tribase::motorA;
Actuators::Motor* DriveTrain::Tribase::motorB;
Actuators::Motor* DriveTrain::Tribase::motorC;

DriveTrain::Tribase::Tribase(Actuators::Motor* m1, Actuators::Motor* m2, Actuators::Motor* m3, Pose2D* pose, float center, float radius)
  : pose(pose), center(center), radius(radius){
//  this->huart = huart;

  motorA = m1;
  motorB = m2;
  motorC = m3;
  controlX = new Algorithm::PID(1, 0, 0, 10);
  controlY = new Algorithm::PID(1, 0, 0, 10);
  controlZ = new Algorithm::PID(1, 0, 0, 10);

  controlPoseX = new Algorithm::PID(1, 0, 0, 10);
  controlPoseY = new Algorithm::PID(1, 0, 0, 10);
  controlPoseZ = new Algorithm::PID(1, 0, 0, 10);

  controlPoseX->set_tolerance(0.08);
  controlPoseY->set_tolerance(0.08);
  controlPoseX->set_tolerance(0.08);
}

void DriveTrain::Tribase::set_speed(float Vx, float Vy, float VW, int32_t encA, int32_t encB, int32_t encC) {
  this->Vx = cos(pose->z) * Vx + sin(pose->z) * Vy;
  this->Vy = -sin(pose->z) * Vx + cos(pose->z) * Vy;

  this->Vw = Vw;
  errorX = controlX->calculate(feedback.Vx, this->Vx);
  errorY = controlY->calculate(feedback.Vy, this->Vy);
  errorZ = controlZ->calculate(feedback.Vz, Vw);

  speedA = (-center * errorZ + errorX) / radius;
  speedB = (-center * errorZ - 0.5 * errorX - 0.865 * errorY) / radius;
  speedC = (-center * errorZ - 0.5 * errorX + 0.865 * errorY) / radius;

  motorA->set_velocity(speedA);
  motorB->set_velocity(speedB);
  motorC->set_velocity(speedC);
//  this->send_packet(speedA, encA, speedB, encB, speedC, encC);
}

void DriveTrain::Tribase::set_speed(float Vx, float Vy, int32_t encA, int32_t encB, int32_t encC) {
  this->Vx = cos(pose->z) * Vx + sin(pose->z) * Vy;
  this->Vy = -sin(pose->z) * Vx + cos(pose->z) * Vy;

  this->Vw = controlPoseZ->calculate(pose->z, this->yaw);

  errorX = controlX->calculate(feedback.Vx, this->Vx);
  errorY = controlY->calculate(feedback.Vy, this->Vy);
  errorZ = controlZ->calculate(feedback.Vz, this->Vw);

  speedA = (-center * errorZ + errorX) / radius;
  speedB = (-center * errorZ - 0.5 * errorX - 0.865 * errorY) / radius;
  speedC = (-center * errorZ - 0.5 * errorX + 0.865 * errorY) / radius;

  this->send_packet(speedA, encA, speedB, encB, speedC, encC);
}

Velocity2D DriveTrain::Tribase::set_position(Pose2D* pose, float poseX, float poseY, float poseZ) {
  Velocity2D speed;
  speed.Vx = controlPoseX->calculate(pose->x, poseX);
  speed.Vy = controlPoseY->calculate(pose->y, poseY);
  speed.Vz = controlPoseZ->calculate(pose->z, poseZ);
  return speed;
}

void DriveTrain::Tribase::send_packet(float Asetpoint, int32_t encA, float Bsetpoint, int32_t encB, float Csetpoint, int32_t encC) {
 this->encoderA=Asetpoint;
	currReadings = encA * 6.28 / 550.0;
  input = (float)((currReadings - prevReadings) / HAL_GetTick()-prevtime);
  outputA =100; //controllerA->calculate(input, Asetpoint);
  prevReadings = currReadings;
  prevtime =HAL_GetTick();
//  if (controllerA->at_setpoint()) {
//    motorA->brake();
//  } else
  if (outputA > 0) {
    motorA->anti_clockwise(outputA);
  }
//    else if (outputA < 0) {
//    motorA->clockwise((uint8_t)fabs(outputA));
//  }

  currReadings = encB * 6.28 / 550.0;
  input = (float)((currReadings - prevReadings) / 0.001);
  prevReadings = currReadings;
  outputB = controllerB->calculate(input, Bsetpoint);
  if (controllerB->at_setpoint()) {
    motorB->brake();
  } else if (outputB > 0) {
    motorB->anti_clockwise((uint8_t)outputB);
  } else if (outputB < 0) {
    motorB->clockwise((uint8_t)fabs(outputB));
  }

  currReadings = encC * 6.28 / 550.0;
  input = (float)((currReadings - prevReadings) / 0.001);
  prevReadings = currReadings;
  output = controllerC->calculate(input, Csetpoint);
  if (controllerC->at_setpoint()) {
    motorC->brake();
  } else if (output > 0) {
    motorC->anti_clockwise((uint8_t)output);
  } else if (output < 0) {
    motorC->clockwise((uint8_t)fabs(output));
  }
}
