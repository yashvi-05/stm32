/*
 *  Trapezoidal.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */


#include <Trapezoidal.h>
#include "math.h"

Profile::Trapezoidal::Trapezoidal(float update_time, float factor) {
  this->update_time = update_time;
  this->factor = factor;
}

float Profile::Trapezoidal::calculate_distance(float q0, float qf, float tf, float v) {
  this->v_max = ((factor * (qf - q0)) / tf);
  this->v_max = (fmin(v_max, v));
  this->tb = ((q0 - qf + (v_max * tf)) / v_max);

  if (t <= tf) {
    t += update_time;
    if (t <= tb) {
      this->distance = (q0 + (v_max / (2 * tb)) * (t * t));
    } else if (t <= tf - tb) {
      this->distance = (((qf + q0 - (v_max * tf)) / 2) + v_max * t);
    } else {
      this->distance = (qf - ((v_max / (2 * tb)) * (tf * tf)) + (v_max * (tf / tb) * t) - (v_max / (2 * tb) * (t * t)));
    }
  }
  return distance;
}
