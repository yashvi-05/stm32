/*
 *  odometry.cpp
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#include "odometry.h"

Localization::Odometry::Odometry(long long *encoderX, long long *encoderY, float *angle, float radius) {
  this->encoderX = encoderX;
  this->encoderY = encoderY;
  this->angle = angle;
  speed = { 0, 0, 0 };
  pose = { 0, 0, 0 };
  this->radius = radius;
  factorX = (2 * M_PI * this->radius) / 2400;
  factorY = (2 * M_PI * this->radius) / 2400;
}

void Localization::Odometry::set_offsets(float x_offset, float y_offset) {
  this->x_offset = x_offset;
  this->y_offset = y_offset;
}

//void Localization::Odometry::update_position() {
//	encoderX->update();
//	encoderY->update();
//}

ODOM_Status Localization::Odometry::set_position(Pose2D pose) {
  this->pose = pose;
  //	xLocal = pose.x * cos(pose.z) + pose.y * sin(pose.z);
  //	yLocal = pose.x * -sin(pose.z) + pose.y * cos(pose.z);
  //	this->encoderX->write((long)(xLocal * this->encoderX->get_cpr()));
  //	this->encoderY->write((long)(yLocal * this->encoderY->get_cpr()));
  return ODOM_PASS;
}


Pose2D Localization::Odometry::get_position() {
  prevX = currX;
  prevY = currY;
  prevZ = pose.z;
  pose.z = *angle * M_PI / 180.0;
  currX = *encoderX;
  currY = *encoderY;
  diffZ = pose.z - prevZ;
  diffX = (currX - prevX) * factorX - x_offset * diffZ;
  diffY = (currY - prevY) * factorY - y_offset * diffZ;
  pose.x += diffX * cos(pose.z) - diffY * sin(pose.z);
  pose.y += diffX * sin(pose.z) + diffY * cos(pose.z);
  return pose;
}

Velocity2D Localization::Odometry::get_speed(float dT) {
  speed.Vx = diffX / dT;
  speed.Vy = diffY / dT;
  speed.Vz = diffZ / dT;
  return speed;
}

Pose2D Localization::Odometry::get_reletive_position(float distance, float angle) {
  Pose2D relative_pose;
  relative_pose.z = -(angle * M_PI / 180.0);
  //	float X = (float)(distance * cos(relative_pose.z))/1000;
  //  float Y = (float)(distance * sin(relative_pose.z))/1000;
  float X = (float)(distance * sin(relative_pose.z)) / 1000;
  float Y = (float)(distance * -cos(relative_pose.z)) / 1000;
  relative_pose.x = float(pose.x + (X * cos(pose.z) - Y * sin(pose.z)));
  relative_pose.y = float(pose.y + (X * sin(pose.z) + Y * cos(pose.z)));
  return relative_pose;
}
