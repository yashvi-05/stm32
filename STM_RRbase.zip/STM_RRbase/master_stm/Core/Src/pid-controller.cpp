/*
 * pid-controller.cpp
 *
 *  Created on: Sep 4, 2022
 *      Author: Author: shahjesa15, pheonix17, shubh_gajjar07
 */


#include "pid-controller.h"

Algorithm::PID::PID(double kp, double ki, double kd, double period) {
  this->kp = kp;
  this->ki = ki;
  this->kd = kd;
  this->period = period / 1000.0;
}

double Algorithm::PID::clamp(double value, double low, double high) {
  return value < low ? low : (value > high ? high : value);
}

double Algorithm::PID::calculate(double input, double setpoint) {
  this->setpoint = setpoint;
  return this->calculate(input);
}

double Algorithm::PID::calculate(double input) {
  this->input = input;
  this->prev_error = this->position_error;
  this->position_error = this->setpoint - this->input;
  this->velocity_error = (this->position_error - this->prev_error) / this->period;
  if (this->ki) {
    this->total_error = this->clamp(
      this->total_error + this->position_error * this->period,
      this->min_intergral / this->ki,
      this->max_intergral / this->ki);
  }
  this->output = this->kp * this->position_error + this->ki * this->total_error + this->kd * this->velocity_error;
  this->output = this->clamp(this->output, this->min_limit, this->max_limit);
  return this->output;
}

void Algorithm::PID::set_tunings(double kp, double ki, double kd) {
  this->kp = kp;
  this->ki = ki;
  this->kd = kd;
}

void Algorithm::PID::set_kp(double kp) {
  this->kp = kp;
}

void Algorithm::PID::set_ki(double ki) {
  this->ki = ki;
}

void Algorithm::PID::set_kd(double kd) {
  this->kd = kd;
}

void Algorithm::PID::set_period(double period) {
  this->period = period / 1000.0;
}

void Algorithm::PID::set_setpoint(double setpoint) {
  this->setpoint = setpoint;
  this->position_error = this->setpoint - this->input;
  this->velocity_error = (this->position_error - this->input) / this->period;
}

void Algorithm::PID::set_intergrator_range(double min_intergral, double max_intergral) {
  this->min_intergral = min_intergral;
  this->max_intergral = max_intergral;
}

void Algorithm::PID::set_tolerance(double position_tolerance) {
  this->set_tolerance(position_tolerance, __INT64_MAX__);
}

void Algorithm::PID::set_tolerance(double position_tolerance, double velocity_tolerance) {
  this->position_tolerance = position_tolerance;
  this->velocity_tolerance = velocity_tolerance;
}

void Algorithm::PID::set_output_limits(double min_limit, double max_limit) {
  this->min_limit = min_limit;
  this->max_limit = max_limit;
}

bool Algorithm::PID::at_setpoint() {
  return abs(this->position_error) < this->position_tolerance && abs(this->velocity_error) < this->velocity_tolerance;
}

double Algorithm::PID::get_kp() {
  return this->kp;
}

double Algorithm::PID::get_ki() {
  return this->ki;
}

double Algorithm::PID::get_kd() {
  return this->kd;
}

double Algorithm::PID::get_period() {
  return this->period;
}

double Algorithm::PID::get_setpoint() {
  return this->setpoint;
}

double Algorithm::PID::get_output() {
  return this->output;
}

double Algorithm::PID::get_position_error() {
  return this->position_error;
}

double Algorithm::PID::get_velocity_error() {
  return this->velocity_error;
}

void Algorithm::PID::reset() {
  this->position_error = this->velocity_error = this->total_error = this->prev_error = 0;
}
