/*
 * Encoder_timer.h
 *
 *  Created on: Sep 4, 2022
 *  Author: shahjesal15, pheonix17, shubh_gajjar07
 */

#ifndef INC_ENCODER_TIMER_H_
#define INC_ENCODER_TIMER_H_

#include "main.h"

namespace Sensors {
	class Encoder_timer{
		public:
			TIM_HandleTypeDef *encoder_tim;
			volatile int32_t ticks = 0,
					counts = 0,
					revolutions = 0;
			int32_t cpr = 1000;
			Encoder_timer(TIM_HandleTypeDef *encoder_tim, int32_t cpr = 1000);
			void begin();
			void write(int32_t counts);
			int32_t get_cpr() { return cpr; };
			int32_t read();
			void update(TIM_HandleTypeDef *encoder_tim);
	};
}

#endif /* INC_ENCODER_TIMER_H_ */
