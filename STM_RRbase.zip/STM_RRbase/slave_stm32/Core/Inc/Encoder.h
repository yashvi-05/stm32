/*
 *  Encoder.h
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 *  refer : https://robu.in/product/incremental-optical-rotary-encoder-6002400-pulse-600-ppr/?gclid=CjwKCAjwscGjBhAXEiwAswQqNDc4HHohENaeZ23OpaCop73IPW-LUKrKHrJ42yftrqOlECX64xapKRoC_2EQAvD_BwE
 */

#ifndef INC_ENCODER_H_
#define INC_ENCODER_H_

#include "main.h"

namespace Sensors {
	class Encoder{
		public:
			int MSB = 0, LSB = 0, encoded = 0, sum = 0, lastEncoded = 0;
			volatile int32_t ticks = 0,
					counts = 0,
					revolutions = 0;
			GPIO_TypeDef *portA, *portB;
			uint32_t pinA, pinB;
			int32_t cpr = 1000;
			Encoder(GPIO_TypeDef *portA, uint32_t pinA, GPIO_TypeDef *portB, uint32_t pinB, int32_t cpr);
			void update();
			int32_t get_cpr() { return cpr; };
			void write(int32_t count);
			int32_t read();
	};
}

#endif /* INC_ENCODER_H_ */
