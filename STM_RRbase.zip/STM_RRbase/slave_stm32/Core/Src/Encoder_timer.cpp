/*
 * Encoder_timer.cpp
 *
 *  Created on: Sep 4, 2022
 *  Author: shahjesal15, pheonix17, shubh_gajjar07
 */

#include "Encoder_timer.h"

Sensors::Encoder_timer::Encoder_timer(TIM_HandleTypeDef *encoder_tim, int32_t cpr) {
	this->encoder_tim = encoder_tim;
	this->cpr = cpr;
}

void Sensors::Encoder_timer::begin() {
	HAL_TIM_Encoder_Start_IT(this->encoder_tim, TIM_CHANNEL_ALL);
}

void Sensors::Encoder_timer::write(int32_t counts) {
	this->ticks = counts % this->cpr;
	this->revolutions = counts / this->cpr;
	this->counts = counts;
	__HAL_TIM_SET_COUNTER(this->encoder_tim, (uint16_t)this->ticks);
}

int32_t Sensors::Encoder_timer::read() {
	this->counts = this->revolutions * this->cpr + this->ticks;
	return this->counts;
}

void Sensors::Encoder_timer::update(TIM_HandleTypeDef *encoder_tim) {
	if(encoder_tim == this->encoder_tim) {
		this->ticks = (int16_t)__HAL_TIM_GET_COUNTER(this->encoder_tim);
		if(this->ticks < -this->cpr) {
			this->revolutions--;
			this->ticks += this->cpr;
			__HAL_TIM_SET_COUNTER(this->encoder_tim, (uint16_t)this->ticks);
		} else if(this->ticks > this->cpr) {
			this->revolutions++;
			this->ticks -= this->cpr;
			__HAL_TIM_SET_COUNTER(this->encoder_tim, (uint16_t)this->ticks);
		}
	}
}
