/*
 *  Encoder.cpp
 *
 *  Created on: Feb 25, 2024
 *  Author: GTU-Robotics-Club
 */

#include "Encoder.h"

Sensors::Encoder::Encoder(GPIO_TypeDef *portA, uint32_t pinA, GPIO_TypeDef *portB, uint32_t pinB, int32_t cpr) {
	this->portA = portA;
	this->portB = portB;
	this->pinA = pinA;
	this->pinB = pinB;
	this->cpr = cpr;
}

void Sensors::Encoder::write(int32_t counts) {
	this->ticks = counts % this->cpr;
	this->revolutions = counts / this->cpr;
	this->counts = counts;
}

int32_t Sensors::Encoder::read() {
	this->counts = this->revolutions * this->cpr + this->ticks;
	return this->counts;
}

void Sensors::Encoder::update() {
	MSB = HAL_GPIO_ReadPin(this->portA, this->pinA) == GPIO_PIN_SET ? 1 : 0;
	LSB = HAL_GPIO_ReadPin(this->portB, this->pinB) == GPIO_PIN_SET ? 1 : 0;
	encoded = (MSB << 1) | LSB;
	sum = (lastEncoded << 2) | encoded;
	if(sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) {
		ticks++;
		if(ticks > this->cpr){
			this->revolutions++;
			this->ticks -= this->cpr;
		}
	} if(sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000){
		ticks--;
		if(ticks < -this->cpr){
			this->revolutions--;
			this->ticks += this->cpr;
		}
	}
	this->counts = this->revolutions * this->cpr + this->ticks;
	lastEncoded = encoded;
}
