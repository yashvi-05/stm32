#ifndef SRC_MOTOR_H
#define SRC_MOTOR_H

#include "Arduino.h"
// #include "analogWrite.h"


class MOTOR {
public:
  int dir1;
  int pwm2;
  int max_speed = 0;
  bool direction = 0;
public:
  MOTOR(int dir1, int pwm2, int max_speed);
  void clockwise(int p);
  void anticlockwise(int p);
  void breakmotor();
  void set_velocity(float speed);
};
#endif
