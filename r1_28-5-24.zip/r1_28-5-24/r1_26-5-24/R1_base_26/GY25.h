
#ifndef SRC_GY25_H_
#define SRC_GY25_H_

#include "Arduino.h"
namespace Sensors {
class GY_25 {
private:
  unsigned char mode = 0xA5, command = 0x51;
  HardwareSerial* GYSerial;

public:
  int16_t z;
  uint8_t Re_buf[8];
  GY_25(HardwareSerial* Serial);
  void GY25_Transmit();
  void GY25_Receive();
  float get_yaw(){return this->z;};
};
};
#endif /* SRC_GY25_H_ */
