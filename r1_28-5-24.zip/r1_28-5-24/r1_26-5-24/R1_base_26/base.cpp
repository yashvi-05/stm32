#include "base.h"
#include "motor.h"

//controlCytron m1,m2,m3,m4;
//MOTOR* m1;
//MOTOR* m2;
//MOTOR* m3;

MOTOR m1(26, 27, 700);
MOTOR m2(33, 25, 1100);
MOTOR m3(22, 21, 1000);

base::base(MOTOR* motor1, MOTOR* motor2, MOTOR* motor3) {
  m1 = motor1;
  m2 = motor2;
  m3 = motor3;
}

void base::forward(int speedA, int speedB, int speedC) {
  m1->breakmotor();
  m2->clockwise(speedB);
  m3->anticlockwise(speedC);
}
void base::backward(int speedA, int speedB, int speedC) {
  m1->breakmotor();
  m2->anticlockwise(speedB);
  m3->clockwise(speedC);
}

void base::right(int speedA, int speedB, int speedC) {
  m1->anticlockwise(speedA);
  m2->clockwise(speedB);
  m3->clockwise(speedC);
}
void base::left(int speedA, int speedB, int speedC) {
  m1->clockwise(speedA);
  m2->anticlockwise(speedB);
  m3->anticlockwise(speedC);
}
void base::topright(int speedA, int speedB, int speedC) {
  m1->anticlockwise(speedA);
  m2->clockwise(speedB);
  m3->breakmotor();
}
void base::topleft(int speedA, int speedB, int speedC) {
  m1->clockwise(speedA);
  m2->breakmotor();
  m3->anticlockwise(speedC);
}
void base::clockwise(int speedA, int speedB, int speedC) {
  m1->anticlockwise(speedA);
  m2->anticlockwise(speedB);
  m3->anticlockwise(speedC);
}
void base::anticlockwise(int speedA, int speedB, int speedC) {
  m1->clockwise(speedA);
  m2->clockwise(speedB);
  m3->clockwise(speedC);
}
void base::bottomleft(int speedA, int speedB, int speedC) {
  m1->clockwise(speedA);
  m2->anticlockwise(speedB);
  m3->breakmotor();
}
void base::bottomright(int speedA, int speedB, int speedC) {
  m1->anticlockwise(speedA);
  m2->breakmotor();
  m3->clockwise(speedC);
}
void base::brake() {
  m1->breakmotor();
  m2->breakmotor();
  m3->breakmotor();
}
