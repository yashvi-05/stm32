#ifndef INC_BASE_H_
#define INC_BASE_H_

#include "motor.h"

class base {
private:
  MOTOR* m1;
  MOTOR* m2;
  MOTOR* m3;

public:
  // void baseInit();
  base(MOTOR* motor1, MOTOR* motor2, MOTOR* motor3);

  void forward(int speedA, int speedB, int speedC);
  void backward(int speedA, int speedB, int speedC);

  void right(int speedA, int speedB, int speedC);
  void left(int speedA, int speedB, int speedC);

  void up_right(int speedA, int speedB, int speedC);
  void down_right(int speedA, int speedB, int speedC);

  void up_left(int speedA, int speedB, int speedC);
  void down_left(int speedA, int speedB, int speedC);

  void topright(int speedA, int speedB, int speedC);
  void topleft(int speedA, int speedB, int speedC);
  void bottomright(int speedA, int speedB, int speedC);
  void bottomleft(int speedA, int speedB, int speedC);

  void clockwise(int speedA, int speedB, int speedC);
  void anticlockwise(int speedA, int speedB, int speedC);

  void brake();
};
#endif /* INC_BASE_H_ */
