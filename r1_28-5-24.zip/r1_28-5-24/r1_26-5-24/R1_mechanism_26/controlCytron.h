#ifndef INC_CONTROLCYTRON_H_
#define INC_CONTROLCYTRON_H_

#include "Arduino.h"
#include <math.h>

class controlCytron {
private:
  uint8_t address;
  uint8_t channel;
  uint8_t dummybyte = 128;
  uint8_t packet[4] = { 85, 0, 0, 0 };
  HardwareSerial* MDDSSerial;
public:
  controlCytron(HardwareSerial* MDDSSerial, uint8_t address, uint8_t channel);
  void sendFirstbyte();
  void clockwise(uint8_t command);
  void counterClockwise(uint8_t command);
  void brakeMotor();
  void sendCmd(uint8_t power);
  void motorControl(int speed);
};

#endif /* INC_CONTROLCYTRON_H_ */
