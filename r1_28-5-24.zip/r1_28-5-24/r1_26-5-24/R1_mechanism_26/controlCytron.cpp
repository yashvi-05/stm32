#include "controlCytron.h"
//#define map(val, Imin, Imax, Omin, Omax) ((((val - Imin) * (Omax - Omin)) / (Imax - Imin)) + Omin)
//#define constrain(val, Omin, Omax) ((val > Omax) ? Omax : (val < Omin) ? Omin : val)

controlCytron::controlCytron(HardwareSerial* MDDSSerial, uint8_t address, uint8_t channel) {
  this->MDDSSerial = MDDSSerial;
  this->address = address;
  if (channel == 1) {
    this->address = address | 0b00001000;
  } else if (channel == 0) {
    this->address = address;
  }
  this->packet[1] = this->address;
}

void controlCytron::sendFirstbyte() {
  delay(1000);
  MDDSSerial->write(dummybyte);
}

void controlCytron::clockwise(uint8_t command) {
  this->packet[2] = command * 127 / 100 + 128;
  sendCmd(this->packet[2]);
}

void controlCytron::counterClockwise(uint8_t command) {
  this->packet[2] = command * (-126) / 100 + 126;
  sendCmd(this->packet[2]);
}

void controlCytron::brakeMotor() {
  this->packet[2] = 127;
  sendCmd(this->packet[2]);
}

void controlCytron::motorControl(int speed) {
  if (speed > 0) {
    clockwise(constrain(abs(speed), 0, 100));
  } else if (speed < 0) {
    counterClockwise(constrain(abs(speed), 0, 100));

  } else if (speed == 0) {
    brakeMotor();
  }
}

void controlCytron::sendCmd(uint8_t power) {
  // Serial.println(packet[1]);
  this->packet[3] = this->packet[0] + this->packet[1] + power;
  for (int i = 0; i < 4; i++) {
    MDDSSerial->write(packet[i]);
  }
}
